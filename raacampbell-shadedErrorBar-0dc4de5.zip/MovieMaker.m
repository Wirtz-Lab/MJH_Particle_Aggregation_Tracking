timePoints = 39
j=1
u = uicontrol('Style','slider','Position',[10 50 20 340],...
    'Min',1,'Max',timePoints,'Value',1);
for j = j:timePoints

A = DataC1.well9.ObjectCentroids(j).AllobjectCents(:,1);
B = DataC1.well9.ObjectCentroids(j).AllobjectCents(:,2);
C = DataC2.well9.ObjectCentroids(j).AllobjectCents(:,1);
D = DataC2.well9.ObjectCentroids(j).AllobjectCents(:,2);
E = DataC3.well9.ObjectCentroids(j).AllobjectCents(:,1);
F = DataC3.well9.ObjectCentroids(j).AllobjectCents(:,2);

plot(A,B,'c.','MarkerSize',10);

hold on 
plot(C,D,'g.','MarkerSize',5);
% plot(E,F,'rx','MarkerSize',5);
xlim([0, 2048]);
ylim([0, 2048]);
whitebg('k');
hold off
M(j)= getframe;
end

movie(M,15)

